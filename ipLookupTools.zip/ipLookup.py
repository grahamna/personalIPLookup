import webbrowser, time

# Path to browser executable
browser = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe %s"

# List of Links used for IP lookup

links = {"https://www.abuseipdb.com/check/","https://www.virustotal.com/gui/ip-address/", "https://talosintelligence.com/reputation_center/lookup?search=","https://otx.alienvault.com/indicator/ip/"}

# function to iterate over links, opening new web browser page and new tabs with the passed in ip address
def lookup(ipAddress):
    webbrowser.open_new("https://www.abuseipdb.com/check/"+ipAddress)
    time.sleep(0.25)
    webbrowser.open_new_tab("https://www.virustotal.com/gui/ip-address/"+ipAddress)
    time.sleep(0.25)
    webbrowser.open_new_tab("https://talosintelligence.com/reputation_center/lookup?search="+ipAddress)
    time.sleep(0.25)
    webbrowser.open_new_tab("https://otx.alienvault.com/indicator/ip/"+ipAddress)


def main():
    while True:
        ipAddress = input("Enter IP: ")
        exitStatement = "q"
        if ipAddress == exitStatement:
            print("exiting")
            exit()
        print("Looking up IP "+ ipAddress)
        lookup(ipAddress)

if __name__ == '__main__':
    main()